from flask import Flask, render_template, request
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.cluster import KMeans

app = Flask(__name__)

# Load dataset
data = pd.read_csv('dataset/weather_data.csv')

# Preprocessing
def preprocess_data(df):
    df.fillna(method='ffill', inplace=True)
    return df

# Machine Learning Models
def train_models(data):
    # Model Features and Labels
    features = data[['temperature_celsius', 'humidity', 'wind_mph']]
    labels = data['condition_text']
    
    # Train/Test Split
    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2)

    # Decision Tree Classifier
    dt_model = DecisionTreeClassifier()
    dt_model.fit(X_train, y_train)

    # Naive Bayes Classifier
    nb_model = GaussianNB()
    nb_model.fit(X_train, y_train)

    return dt_model, nb_model

# Train models
dt_model, nb_model = train_models(preprocess_data(data))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    temperature = float(request.form['temperature'])
    humidity = float(request.form['humidity'])
    wind_speed = float(request.form['wind_speed'])

    features = [[temperature, humidity, wind_speed]]
    prediction_dt = dt_model.predict(features)
    prediction_nb = nb_model.predict(features)

    return render_template('details.html', prediction_dt=prediction_dt[0], prediction_nb=prediction_nb[0])

if __name__ == '__main__':
    app.run(debug=True)