// **Dataset: Available Cities**
const cities = [
    { name: "Quito", country: "Ecuador" },
    { name: "Santo Domingo", country: "Dominican Republic" },
    { name: "Panamá Viejo", country: "Panama" },
    { name: "San José", country: "Costa Rica" }
];

// **Example Simulated Weather Data per City**
const weatherData = {
    "Quito": { temp: 9, summary: "Cloudy", high: 12, low: 5 },
    "Santo Domingo": { temp: 23, summary: "Sunny", high: 29, low: 18 },
    "Panamá Viejo": { temp: 26, summary: "Partly Cloudy", high: 28, low: 21 },
    "San José": { temp: 19, summary: "Rainy", high: 21, low: 17 }
};

// **Populate the City Dropdown**
window.onload = function() {
    const citySelect = document.getElementById('citySelect');
    cities.forEach(city => {
        const option = document.createElement('option');
        option.value = city.name;
        option.textContent = `${city.name}, ${city.country}`;
        citySelect.appendChild(option);
    });

    // Update weather info on selection change
    citySelect.addEventListener('change', updateWeatherInfo);

    // Optionally, display weather for the first city on load
    updateWeatherInfo();
};

// **Show Weather Data for Selected City**
function updateWeatherInfo() {
    const citySelect = document.getElementById('citySelect');
    const selectedCity = citySelect.value;
    const weather = weatherData[selectedCity];

    const weatherDiv = document.getElementById('weatherInfo');
    if (weather) {
        weatherDiv.innerHTML = `
            <h2>Weather for ${selectedCity}</h2>
            <ul>
                <li><strong>Temperature:</strong> ${weather.temp}°C</li>
                <li><strong>Summary:</strong> ${weather.summary}</li>
                <li><strong>High:</strong> ${weather.high}°C</li>
                <li><strong>Low:</strong> ${weather.low}°C</li>
            </ul>
        `;
    } else {
        weatherDiv.innerHTML = "<p>Please select a city.</p>";
    }
}